from operaciones.basicas import agregar_tarea, completar_tarea, eliminar_tarea

tareas = []

agregar_tarea(tareas, "Estudiar matemática")
agregar_tarea(tareas, "Preparar el trabajo práctico")

print("Tareas actuales:", tareas)

completar_tarea(tareas, 0)
print("Tareas luego de completar la primera:", tareas)

eliminar_tarea(tareas, 1)
print("Tareas luego de eliminar la segunda:", tareas)