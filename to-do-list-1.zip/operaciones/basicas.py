def agregar_tarea(tareas, descripcion):
    tareas.append({"descripcion": descripcion, "completada": False})

def completar_tarea(tareas, indice):
    if 0 <= indice < len(tareas):
        tareas[indice]["completada"] = True

def eliminar_tarea(tareas, indice):
    if 0 <= indice < len(tareas):
        tareas.pop(indice)