# To-Do List (Lista de Tareas)

Este es un proyecto básico en Python para gestionar tareas personales.

## Funcionalidades
- Agregar nuevas tareas
- Marcar tareas como completadas
- Eliminar tareas

## Uso
1. Ejecutá `main.py`
2. Modificá el código para agregar tus propias tareas

## Estructura
- `operaciones/basicas.py`: contiene las funciones principales
- `main.py`: archivo principal de ejecución